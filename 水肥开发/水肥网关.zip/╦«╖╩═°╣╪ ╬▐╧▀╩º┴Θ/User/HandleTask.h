#ifndef __HandleTask_H
#define __HandleTask_H

#include "stm32f10x.h"

#ifdef __cplusplus
extern "C"
{
#endif

void  Period_Events_Handle(u32 Events);
void  Scan_Events_Handle(void);

#ifdef __cplusplus
}
#endif

#endif
